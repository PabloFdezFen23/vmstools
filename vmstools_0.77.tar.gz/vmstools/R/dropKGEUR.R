dropKGEUR <- function(x){
	return(x[,-kgeur(colnames(x))])}